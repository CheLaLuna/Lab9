// BEGIN
export function Money(value, currency = 'usd') {
    this.value = value;
    this.currency = currency;
  }
  
  Money.prototype.getValue = function() {
    return this.value;
  };
  
  Money.prototype.getCurrency = function() {
    return this.currency;
  };
  
  Money.prototype.exchangeTo = function(currency) {
    let newValue;
    if (this.currency === 'usd' && currency === 'eur') {
      newValue = this.value * 0.7;
    } else if (this.currency === 'eur' && currency === 'usd') {
      newValue = this.value * 1.2;
    } else {
      return new Money(this.value, this.currency);
    }
    return new Money(newValue, currency);
  };
  
  Money.prototype.add = function(money) {
    let newValue;
    if (this.currency !== money.getCurrency()) {
      const convertedMoney = money.exchangeTo(this.currency);
      newValue = this.value + convertedMoney.getValue();
    } else {
      newValue = this.value + money.getValue();
    }
    return new Money(newValue, this.currency);
  };
  
  Money.prototype.format = function() {
    const formattedValue = this.value.toLocaleString(undefined, { style: 'currency', currency: this.currency });
    return formattedValue;
  };
  
export default Money;
// END
